let diseaseData = [];

Papa.parse("plant_disease_data.csv", {
  download: true,
  header: true,
  complete: function (results) {
    diseaseData = results.data;
  }
});

function checkDisease() {
  const input = document.getElementById("imageInput");
  if (!input.files.length) {
    alert("Please select an image.");
    return;
  }

  const file = input.files[0];
  const fileName = file.name;

  const match = diseaseData.find(row => row.image.trim() === fileName.trim());
  const resultDiv = document.getElementById("result");

  if (match) {
    resultDiv.innerHTML = `
      <h3>Diagnosis</h3>
      <p><strong>Plant:</strong> ${match.plant}</p>
      <p><strong>Disease:</strong> ${match.disease}</p>
      <p><strong>Symptoms:</strong> ${match.symptoms}</p>
      <p><strong>Precautions:</strong> ${match.precautions}</p>
    `;
  } else {
    resultDiv.innerHTML = <p style="color:red;">No match found for this image. Try again.</p>;
  }

  input.value = ""; // Reset input
}